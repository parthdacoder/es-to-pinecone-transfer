"""
Tests for the ES to Pinecone transfer pipeline.
"""